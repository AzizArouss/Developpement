<?php
include(PATH_MODEL.'/'.$page.'.model.php');
include (PATH_VUE.'/layout.phtml');