<?php

include (PATH_MODEL.'/'.$page.'.model.php');